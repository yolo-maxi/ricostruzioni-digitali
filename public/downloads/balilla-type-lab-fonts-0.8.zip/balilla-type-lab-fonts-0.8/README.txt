BALILLA TYPE LAB FONTS, release 0.8

Two study reconstructions of lettering from two photographed 1930s Italian booklet covers.
Each font is traced from one selected sample. Each font file is compared with its own sample.
The two fonts are separate: no shape of one is used in another.

CONTENTS
  README.txt                      this file
  LICENSE.txt                     CC BY 4.0 licence and attribution
  SHA256SUMS.txt                  SHA-256 of the other files
  Balilla-Reconstructed/
    Balilla-Reconstructed.ttf, Balilla-Reconstructed.woff2
    NOTES.txt                     source sample, method, score, glyph labels
    evaluation-report.json        the measured comparison
  Balilla-Panel-Reconstructed/
    Balilla-Panel-Reconstructed.ttf, Balilla-Panel-Reconstructed.woff2
    NOTES.txt
    evaluation-report.json
    evidence/panel-glyph-s-overlay.png
    evidence/panel-glyph-t-overlay.png
    evidence/panel-glyph-z-overlay.png                                  difference images of the glyphs s, t and z

1. Balilla — cover capitals   (family "Balilla Reconstructed", version 0.2)
   Source sample: Row 2 (EDUCAZIONE) of the knocked-out capitals on the burgundy cover.
   Scored text: DUCAZION. Dice 99.64%, IoU 99.28%. Gate Dice >= 95%: pass.
   Traced letters: A C D I N O U Z E L R S T. All other glyphs are labelled extrapolations.
   Lower-case keys show the capitals.

2. Balilla Panel — pale panel lettering   (family "Balilla Panel Reconstructed", version 0.1)
   Source sample: The pale thin lettering "mini- stero educa- zione nazio- nale" (ministero educazione nazionale) inside the dark green panel of the obelisk cover: six lines, 28 letters and 3 hyphens.
   All 31 observed shapes: Dice 93.43%, IoU 87.66%.
   The 15 shapes that the glyphs were traced from: Dice 98.19%, IoU 96.43%.
   The 16 other occurrences of repeated letters: Dice 88.98%, IoU 80.14%.
   Gate Dice >= 95% for each traced glyph, compared with the shape that it was traced from: pass.
   Traced glyphs: - a c d e i l m n o r s t u z. All other glyphs are labelled extrapolations.
   Capital keys show the lower case. The letter i has no dot, as in the source.

WHAT THE SCORES MEAN
A score shows how well a font file reproduces the photographed sample that it was traced from,
after one uniform scale and one shift for the whole sample. It is not an independent test of the
letter shapes. It does not cover the extrapolated glyphs. No score is 100%.
The panel lettering is drawn by hand with a thin stroke. The font holds one observed shape for each
letter, so the other occurrences of a repeated letter score lower than the traced one.

INSTALL
Desktop: open the .ttf file and select Install.
Web: use the .woff2 file with @font-face.

More detail is in the NOTES.txt file of each face.
